
KamartaLogin - Expo React Native project
---------------------------------------

How to run:

1) Install Node.js (LTS) from https://nodejs.org
2) Install Expo CLI globally (optional) or use npx:
   npm install -g expo-cli
   # or use npx expo start
3) Open terminal and run:
   cd KamartaLogin
   npm install
   expo start

4) Install the Expo Go app on your phone and scan the QR code shown by expo start.

Notes:
- Background image is included in assets/bg.png (the image you provided).
- If npm install fails, try using yarn:
   npm install -g yarn
   yarn install

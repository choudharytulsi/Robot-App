import React, { useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  ImageBackground,
  TextInput,
  TouchableOpacity,
  Platform,
  StatusBar,
} from "react-native";

const bg = require("./assets/bg.png");

export default function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPwd, setShowPwd] = useState(false);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" />
      <ImageBackground source={bg} style={styles.background} resizeMode="cover">
        <View style={styles.topArea}>
          <Text style={styles.logoText}>Kamarta{"\n"}<Text style={styles.logoSub}>Robotics</Text></Text>
        </View>

        <View style={styles.centerArea}>
          <View style={styles.card}>
            <Text style={styles.loginTitle}>LOGIN</Text>
            <Text style={styles.roleText}>Developer | Business</Text>

            <View style={styles.inputWrap}>
              <Text style={styles.label}>Username</Text>
              <View style={styles.inputRow}>
                <TextInput
                  value={username}
                  onChangeText={setUsername}
                  placeholder="Username"
                  placeholderTextColor="#8fb6c0"
                  style={styles.input}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                <View style={styles.iconBox} />
              </View>
            </View>

            <View style={[styles.inputWrap, { marginTop: 12 }]}>
              <Text style={styles.label}>Password</Text>
              <View style={styles.inputRow}>
                <TextInput
                  value={password}
                  onChangeText={setPassword}
                  placeholder="**********"
                  placeholderTextColor="#8fb6c0"
                  secureTextEntry={!showPwd}
                  style={styles.input}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                <TouchableOpacity
                  style={styles.iconBox}
                  onPress={() => setShowPwd(!showPwd)}
                />
              </View>
            </View>

            <TouchableOpacity style={styles.forgotWrap}>
              <Text style={styles.forgotText}>Forgot Password ?</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.bottomArea}>
          <TouchableOpacity style={styles.loginBtn}>
            <Text style={styles.loginBtnText}>LOGIN</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#071a2b",
  },
  background: {
    flex: 1,
    paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0,
    alignItems: "center",
    justifyContent: "space-between",
  },
  topArea: {
    width: "100%",
    alignItems: "center",
    marginTop: 28,
  },
  logoText: {
    color: "#ffffff",
    fontSize: 36,
    fontWeight: "700",
    textAlign: "center",
    letterSpacing: 1,
  },
  logoSub: {
    fontSize: 14,
    fontWeight: "600",
    color: "#9fe7e0",
  },

  centerArea: {
    flex: 1,
    width: "92%",
    alignItems: "center",
    justifyContent: "center",
  },

  card: {
    width: "92%",
    backgroundColor: "rgba(12,30,45,0.65)",
    borderRadius: 12,
    paddingVertical: 22,
    paddingHorizontal: 18,
    borderWidth: 2,
    borderColor: "#0fd7c9",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 6,
  },

  loginTitle: {
    color: "#e7ffff",
    fontSize: 28,
    fontWeight: "800",
    textAlign: "left",
  },
  roleText: {
    color: "#9fdbe0",
    fontSize: 12,
    marginTop: 2,
    marginBottom: 16,
  },

  inputWrap: {
    marginTop: 8,
  },
  label: {
    color: "#cfeff1",
    fontSize: 14,
    marginBottom: 6,
    fontWeight: "600",
  },

  inputRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  input: {
    flex: 1,
    height: 48,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#0aa79a",
    color: "#dffaff",
    backgroundColor: "rgba(8,18,25,0.35)",
    fontSize: 16,
  },

  iconBox: {
    width: 42,
    height: 42,
    marginLeft: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#0aa79a",
    backgroundColor: "rgba(11,24,28,0.35)",
  },

  forgotWrap: {
    marginTop: 8,
    alignSelf: "flex-end",
  },
  forgotText: {
    color: "#8fe3db",
    fontSize: 13,
  },

  bottomArea: {
    width: "100%",
    alignItems: "center",
    marginBottom: 28,
  },

  loginBtn: {
    width: "56%",
    maxWidth: 300,
    backgroundColor: "#05222b",
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#0fd7c9",
    shadowColor: "#0fd7c9",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.28,
    shadowRadius: 14,
    elevation: 8,
  },

  loginBtnText: {
    color: "#e8ffff",
    fontWeight: "800",
    fontSize: 18,
    letterSpacing: 1,
  },
});
